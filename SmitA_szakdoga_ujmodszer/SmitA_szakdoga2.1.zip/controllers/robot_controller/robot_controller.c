//the directorys we'll need
#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/distance_sensor.h>
#include <webots/gps.h>
#include <webots/compass.h>
#include <stdio.h>
#include <stdlib.h> 
#include <math.h>

//basic timestep for the world
#define TIME_STEP 64

//initializing the sensors and motors
WbDeviceTag ds[3];
WbDeviceTag wheels[4];
WbDeviceTag gps;
WbDeviceTag comp;

// wheel naming
const char* wheel_names[4] = {"wheel_fl", "wheel_fr",
"wheel_rl","wheel_rr"};
enum WheelDef{
  W_FL = 0,
  W_FR = 1,
  W_RL = 2,
  W_RR = 3
};

// distance sensor naming
const char* ds_names[3] = {"ds_left", "ds_right","ds_mid"};
enum DistanceSensorDef{
  DS_LEFT = 0,
  DS_RIGHT = 1,
  DS_MID =2
};

//setting up the devices for the controller
void init_devices(){
  int i;
 
//the distance sensors
  for (i=0;i<3;++i){
    ds[i] = wb_robot_get_device(ds_names[i]);
    wb_distance_sensor_enable(ds[i], TIME_STEP);
  }
  
//the motors 
  for (i=0;i<4;++i){
    wheels[i] = wb_robot_get_device(wheel_names[i]);
    wb_motor_set_velocity(wheels[i], 0);
    wb_motor_set_position(wheels[i], INFINITY);
  }
  
//the gps
  gps = wb_robot_get_device("gps");
  wb_gps_enable(gps, TIME_STEP);

//the compass
  comp = wb_robot_get_device("compass");
  wb_compass_enable(comp, TIME_STEP); 
}

double map[10][10] = {
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1},
    {1,1,1,1,1,1,1,1,1,1}
};


double target_x;
double target_y;
/*

//x and y coordinates of the targets
double xTarget[5] = {0.5, 1, 4.5, 2, 2.5};
double yTarget[5] = {0.5, 2, 0.5, 4.5, 2.5};

//the before variable prevents the function to give the same target again
int before = 0;
//setting up the target location and the
void set_target(){
  int random_number = rand() % 5;
  if (random_number==before)
  {
    random_number = rand() % 5;
  }
  target_x = xTarget[random_number];
  target_y = yTarget[random_number];
  printf("Target:%d, its coordinates are: %gx / %gy\n",random_number+1,target_x,target_y);
  before=random_number;
}*/

void set_target(){
    target_x = 4.5;
    target_y = 1;
}

//current position coordinates
double pos_x = 0;
double pos_y = 0;
//the target's direction
double target_bearing;
//the values of the distance sensors
double ds_values[3];
//the radius which we count as successful landing
double target_radius = 0.01;

//getting the values of the sensors
void update_sensor_readings(){
  int i;

//the values of the gps
  const double *gps_values = wb_gps_get_values(gps);
  pos_x = gps_values[0];
  pos_y = gps_values[2];

//the values of the distance sensors  
  for (i=0;i<3;++i){
    ds_values[i] = wb_distance_sensor_get_value(ds[i]);
  }
  
//helper variable for counting
  double rad = 0;
//the value of the compass
  const double* north = wb_compass_get_values(comp);
  rad = atan2(north[2],north[0]);
  //counting out the targets direction in degrees
  target_bearing = atan2(-target_y + pos_y,target_x - pos_x);
  target_bearing -= rad;
  target_bearing *= 180 / M_PI;
  if(target_bearing < -180)
  {
    target_bearing += 360;
  }
  if(target_bearing > 180)
  {
    target_bearing -= 360;
  }
  //0 elore, -90 jobbra, 90 balra, 180 mogotte
  target_bearing = target_bearing+90;
}

//setting up the motors speeds
void set_differential_drive(double speed, double diff_speed){
//these variables prevents the motors to get more than 10 velocity
  double left =speed+diff_speed;
  double right = speed-diff_speed;
  if(left > 100) left = 100;
  if(left < -100) left = -100;
  if(right > 100) right = 100;
  if(right < -100) right = -100;
  wb_motor_set_velocity(wheels[W_FL], left);
  wb_motor_set_velocity(wheels[W_FR], right);
  wb_motor_set_velocity(wheels[W_RL], left);
  wb_motor_set_velocity(wheels[W_RR], right);
}

int main(int argc, char **argv) {

//initialize divices and get starting target coordinates
  wb_robot_init();
  init_devices();
  set_target();
  
  //the time when we landed on the target
  double stop_time = 0;
  //this helps counting the time
  int helper = 0;
  //this tells whether we have to turn or we are facing in the right direction
  int turn = 1;
  //this tells if we are on the target
  int stop = 0;
  //this counts the successful landings
  int counter = 0;

  while (wb_robot_step(TIME_STEP) != -1) {
    
    //getting the sensor values every cycle
    update_sensor_readings();
    //the current time of the simulation
    double time = 0.0;
    time=wb_robot_get_time(); 
    
    //the forward and turning speed
    double speed = 10;
    double diff_speed = 0;
    
    //how far we are from the target
    double target_distance = fabs(pos_x - target_x) + fabs(pos_y - target_y);

    printf("target bearing: %fl\n",target_bearing);
    //if we are close enough, we stop and increase the helper value
    if (target_distance < 10 * target_radius)
    {
      stop = 1;
      helper++;
      //if we are sure we landed
      if(helper == 1)
      {
        //which target
        counter++;
        //a nice prospectus
        printf("%d. target reached, in %g seconds. Good job!\n",counter, time);
        //the time we landed
        stop_time=wb_robot_get_time();
      }
      //we stop there for 3 seconds
      if(time - stop_time > 3.0)
      {
        //after 3 seconds, get a new target
        set_target();
        //we can move now
        stop = 0;
        //we are not on the target
        helper = 0;
        //turn in the new target direction
        turn = 1;
      }
    }
    
    //if we can move
    if(stop == 0)
    {
      //if we are close to the target
      if (target_distance < 20 * target_radius)
      {
        //slow down, so we wont miss it
        speed = 1;
      }
      //if we have to turn
      if(turn == 1)
      {
        //turn until we face in the right direction, without moving forward
        if(target_bearing >= -90 && target_bearing <= -30)
        {
        //printf("nagyon jobbra\n");
          diff_speed = 15;
          speed = 0;
        }
        if(target_bearing > -30 && target_bearing <= -10)
        {
        //printf("jobbra\n");
          diff_speed = 7.5;
          speed = 2;
        }
        if(target_bearing >= 180)
        {
        //printf("hatul jobbra\n");
          diff_speed = 20;
          speed = 0;
        }
        //turn until we face in the right direction, without moving forward
        if(target_bearing <= 90 && target_bearing >= 30)
        {
          //printf("nagyon balra\n");
          diff_speed = -15;
          speed = 0;
        }
        if(target_bearing < 30 && target_bearing >= 10)
        {
          //printf("balra\n");
          diff_speed = -7.5;
          speed = 2;
        }
        if(target_bearing > 90 && target_bearing < 180)
        {
        //printf("hatul balra\n");
          diff_speed = -20;
          speed = 0;
        }
        //if we are facing in the right direction, move
        if(target_bearing < 10 && target_bearing > -10)
        {
        printf("egyenes\n");
          turn = 0;
        }
      }
      //if we dont have to turn anymore, simple collision avoid
      else
      {
        //if theres something ahead, avoid collision
        if (ds_values[DS_MID] < 900 && ds_values[DS_MID] >= 500)
        {
          printf("elottem\n");
          speed = 1;
          diff_speed = 20;
          turn = 0;
        }
        else if (ds_values[DS_MID] <= 500 && ds_values[DS_MID] >=150)
        {
          printf("kozvetlen elottem\n");
          speed = 0;
          diff_speed = 40;
          turn = 0;
        }
        else if (ds_values[DS_MID] < 150)
        {
          printf("HOUSTON\n");
          speed = -1;
          diff_speed = 60;
          turn = 0;
        }
        //if there something on the left, turn right
        else if (ds_values[DS_LEFT] < 900 && ds_values[DS_LEFT] >= 500)
        {
          printf("balrol\n");
          speed = 1;
          diff_speed = 20;
          turn = 0;
        }
        else if (ds_values[DS_LEFT] < 500 && ds_values[DS_LEFT] > 0)
        {
          printf("kozvetlen balrol\n");
          speed = 0;
          diff_speed = 40;
          turn = 0;
        }
        //if there something on the right, turn left
        else if (ds_values[DS_RIGHT] < 500 && ds_values[DS_RIGHT] > 0)
        {
          printf("kozvetlen jobbrol\n");
          speed = 0; 
          diff_speed = -40; 
          turn = 0;
        }
        else if (ds_values[DS_RIGHT] < 900 && ds_values[DS_RIGHT] >= 500)
        {
          printf("jobbrol\n");
          speed = 1; 
          diff_speed = -20; 
          turn = 0;
        }
        //if the sensors don't perceive anything
        else
        {
          //turn in the right direction
          //cuz we are most likely facing somewhere else
          turn = 1;
        }
      }
      //set the motor speeds
      set_differential_drive(speed, diff_speed);
    }
    //if we have to stop
    else
    {
      set_differential_drive(0,0);
    }
  };


  wb_robot_cleanup();

  return 0;
}
